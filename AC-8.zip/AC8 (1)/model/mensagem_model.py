class Mensagem():
    def __init__(self, id, id_remetente, id_destinatario, dataMensagem, texto = None):
        self.__id = id
        self.__id_remetente = id_remetente
        self.__id_destinatario = id_destinatario
        self.__dataMensagem = dataMensagem
        self.__texto = texto
   
    def alterar(self, id, id_remetente, id_destinatario, dataMensagem, texto):
        self.__id = id
        self.__id_remetente = id_remetente
        self.__id_destinatario = id_destinatario
        self.__dataMensagem = dataMensagem
        self.__texto = texto

    @property
    def id(self):
        return self.__id
    
    @property
    def id_remetente(self):
        return self.__id_remetente

    @property
    def id_destinatario(self):
        return self.__id_destinatario

    @property
    def dataMensagem(self):
        return self.__dataMensagem

    @property
    def texto(self):
        return self.__texto