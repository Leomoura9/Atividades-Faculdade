import jsons

def to_dict(obj):
    return jsons.dump(obj, strip_privates = True)

def to_disct_list(lista):
    resultado = []
    for x in lista:
        resultado.append(to_dict(x))
    return resultado