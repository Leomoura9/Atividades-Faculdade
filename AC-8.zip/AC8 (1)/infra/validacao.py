def validar_campos(obj, campos, tipos):
    if type(obj) != dict:
        return False

    for k in obj:
        if k not in campos:
            return False
    for k in campos:
        if k not in obj:
            return False

    t = []

    for x in campos:
        t.append(type(obj[x]))
    if t != tipos:
        return False
    return True