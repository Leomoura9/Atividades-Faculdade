import sqlite3 

create_sqls = ["""
CREATE TABLE IF NOT EXISTS Usuario(
    id INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    segredo TEXT
);
""",

"""
CREATE TABLE IF NOT EXISTS Mensagem(
    id INTEGER PRIMARY KEY,
    idRemetente INTEGER,
    idDestinatario INTEGER,
    dataMensagem TEXT,
    texto TEXT,
    FOREIGN KEY (idRemetente) REFERENCES Usuario(id),
    FOREIGN KEY (idDestinatario) REFERENCES Usuario(id)
);
"""
]


from wrap_connection import transact 

def con():
    return sqlite3.connect("chat.db") 

@transact(con) 
def criar_db():
    for sql in create_sqls:
        cursor.execute(sql)
    connection.commit()
