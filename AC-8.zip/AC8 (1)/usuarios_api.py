# from model.aluno import Aluno
from flask import Blueprint, jsonify, request
from infra.validacao import validar_campos
from infra.to_dict import to_dict, to_disct_list
from services.usuarios_service import \
    listar as services_listar_usuarios, \
    localizar as service_buscar_usuario, \
    novo as service_novo_usuario, \
    alterar as service_alterar_usuario, \
    remover as service_remover_usuario, \
    UsuarioJaExiste


usuario_app = Blueprint('usuario_app', __name__, template_folder='templates')
# alunos_db = []

campos = ["id", "nome", "segredo"]
tipos = [int, str, str]

# ROTA: GET | FUNC: BUSCAR TODOS OS CONTEÚDOS DA ARRAY/BANCO DE DADOS CASO CONTENHA DADOS
@usuario_app.route('/usr')
def Index():
    listar = services_listar_usuarios()
    return jsonify(to_dict(listar))


# ROTA: GET | FUNC: BUSCAR CONTEÚDO POR ID, ATRAVÉS DA REQUISIÇÃO VIA URL
@usuario_app.route('/usr/<int:id>', methods=['GET'])
def localizar(id):
#     - csgleirbaG -
    busca = service_buscar_usuario(id)
    if busca != None:
        return jsonify(to_dict(busca))
    return '', 404


# ROTA: POST | FUNC: CADASTRAR CONTEÚDO, ATRAVÉS DAS INFORMAÇÕES ENVIADAS VIA JSON
@usuario_app.route('/usr', methods=['POST'])
def novo():
    import random
    dados = request.get_json()
    dados['id'] = len(to_dict(services_listar_usuarios())) + 1
    dados['segredo'] = ''

    while service_buscar_usuario(dados['id']) != None:
        dados['id'] += 1

    for x in range(0, 5):
        dados['segredo'] += str(random.randrange(0, 10))
    
    if not validar_campos(dados, campos, tipos):
        return '', 422
    try:
        criado = service_novo_usuario(dados['id'], dados['nome'], dados['segredo'])
        return jsonify(to_dict(criado))
    except UsuarioJaExiste:
        return 'Nome de usuário já existente, digite outro nome.', 409



# # ROTA: PUT | FUNC: ALTERAR CONTEÚDO, ATRAVÉS DO ID ENVIADO VIA URL E DAS INFORMAÇÕES ENVIADAS VIA JSON
# @usuario_app.route('/usr/<int:id>', methods=['PUT'])
# def alterar(id):
# #     - csgleirbaG -
#     dados = request.get_json()

#     if not validar_campos(dados, campos, tipos):
#         return '', 422
#     alterado = service_alterar_usuario(id, dados['id'], dados['nome'], dados['segredo'])

#     if alterado != None:
#         return jsonify(to_dict(alterado))
#     return '', 404



# # ROTA: DELETE | FUNC: DELETA A 'CHAVE' CONFORME O ID PASSADO VIA URL
# @usuario_app.route('/usr/<int:id>', methods=['DELETE'])
# def remover(id):
#     removido = service_remover_usuario(id,)
#     if removido != None:
#         return jsonify(to_dict(removido))
#     return '', 404
