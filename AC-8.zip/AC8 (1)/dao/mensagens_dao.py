from infra.db import con 
from wrap_connection import transact
from model.mensagem_model import Mensagem

sql_criar = "INSERT INTO Mensagem(id, idRemetente, idDestinatario, dataMensagem, texto) VALUES (?, ?, ?, ?, ?)"
sql_listar = "SELECT id, idRemetente, idDestinatario, dataMensagem, texto FROM Mensagem"
sql_localizar = "SELECT id, idRemetente, idDestinatario, dataMensagem, texto FROM Mensagem WHERE id = ?"
sql_atualizar = "UPDATE Mensagem SET id = ?, idRemetente = ?, idDestinatario = ?, dataMensagem = ?, texto = ? WHERE id = ?"
sql_remover = "DELETE FROM Mensagem WHERE id = ?"


class UsuarioJaExiste(Exception):
    pass

@transact(con)
def listar():
    cursor.execute(sql_listar) 
    resultado = []
    for r in cursor.fetchall():
        resultado.append(Mensagem(r[0], r[1], r[2], r[3], r[4])) 
    return resultado


@transact(con)
def localizar(id):
    cursor.execute(sql_localizar, (id,)) 
    r = cursor.fetchone() 
    if r == None:
        return None
    return Mensagem(r[0], r[1], r[2], r[3], r[4])

@transact(con)
def criar(mensagem):
    cursor.execute  (sql_criar, (mensagem.id, mensagem.id_remetente, mensagem.id_destinatario, mensagem.dataMensagem, mensagem.texto)) 
    connection.commit() 


@transact(con)
def remover(id):
    # pass
    cursor.execute(sql_remover, (id,))
    connection.commit()

@transact(con)
def atualizar(id_antigo, id_novo, id_remetente, id_destinatario, dataMensagem, texto):
    # pass
    cursor.execute(sql_atualizar, (id_novo, id_remetente, id_destinatario, dataMensagem, texto, id_antigo))
    connection.commit()