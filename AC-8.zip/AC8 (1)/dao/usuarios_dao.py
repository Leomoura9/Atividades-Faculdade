from infra.db import con 
from wrap_connection import transact
from model.usuario_model import Usuario

sql_criar = "INSERT INTO Usuario(id, nome, segredo) VALUES (?, ?, ?)"
sql_listar = "SELECT id, nome, segredo FROM Usuario"
sql_localizar = "SELECT id, nome, segredo FROM Usuario WHERE id = ?"
sql_localizar_nome = "SELECT id, nome, segredo FROM Usuario WHERE nome = ?"
sql_atualizar = "UPDATE Usuario SET id = ?, nome = ?, segredo = ? WHERE id = ?"
sql_remover = "DELETE FROM Usuario WHERE id = ?"


class UsuarioJaExiste(Exception):
    pass

@transact(con)
def listar():
    cursor.execute(sql_listar) 
    resultado = []
    for r in cursor.fetchall():
        resultado.append(Usuario(r[0], r[1], r[2])) 
    return resultado

@transact(con)
def localizar(id):
    cursor.execute(sql_localizar, (id,)) 
    r = cursor.fetchone() 
    if r == None:
        return None
    return Usuario(r[0], r[1], r[2])

@transact(con)
def localizarNome(nome):
    cursor.execute(sql_localizar_nome, (nome,)) 
    r = cursor.fetchone() 
    if r == None:
        return None
    return Usuario(r[0], r[1], r[2])

@transact(con)
def criar(usuario):
    cursor.execute(sql_criar, (usuario.id, usuario.nome, usuario.segredo)) 
    connection.commit() 

@transact(con)
def remover(id):
    # pass
    cursor.execute(sql_remover, (id,))
    connection.commit() 

@transact(con)
def atualizar(id_antigo, id_novo, nome, segredo):
    # pass
    cursor.execute(sql_atualizar, (id_novo, nome, segredo, id_antigo)) 
    connection.commit()