from model.mensagem_model import Mensagem
from infra.log import Log

from dao.mensagens_dao import \
    listar as listar_dao, \
    criar as criar_dao, \
    localizar as localizar_dao, \
    atualizar as atualizar_dao, \
    remover as remover_dao

class MensagemJaExiste(Exception):
    pass

def listar():
    return listar_dao()


def localizar(idMensagem):
#     - csgleirbaG -
    return localizar_dao(idMensagem)


def novo(id, remetente, destinatario, data, texto):
    if localizar(id) != None:
        raise MensagemJaExiste()

    log = Log(None)
    criado = Mensagem(id, remetente, destinatario, data, texto)
    criar_dao(criado)
    log.finalizar(criado)

    return criado


def alterar(idMensagem_atual, idMensagem_novo, remetente, destinatario, data, texto):
#     - csgleirbaG -
    # pass
    mensagem = localizar(idMensagem_atual)
    if mensagem == None:
        return None

    log = Log(mensagem)
    alterado = Mensagem(idMensagem_novo, remetente, destinatario, data, texto)
    atualizar_dao(idMensagem_atual, idMensagem_novo, remetente, destinatario, data, texto)
    log.finalizar(alterado)

    return alterado 
        


def remover(idMensagem):
    # pass
    mensagem = localizar(idMensagem) 

    if mensagem == None:
        return None

    log = Log(mensagem)
    remover_dao(mensagem.id)
    log.finalizar(None)
    
    return mensagem

