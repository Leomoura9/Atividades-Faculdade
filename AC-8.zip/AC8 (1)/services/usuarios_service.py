from model.usuario_model import Usuario
from infra.log import Log

from dao.usuarios_dao import \
    listar as listar_dao, \
    criar as criar_dao, \
    localizar as localizar_dao, \
    localizarNome as localizar_nome_dao, \
    atualizar as atualizar_dao, \
    remover as remover_dao

class UsuarioJaExiste(Exception):
    pass

def listar():
    return listar_dao()


def localizar(idUsuario):
#     - csgleirbaG -
    return localizar_dao(idUsuario)


def localizarNome(nome):
#     - csgleirbaG -
    return localizar_nome_dao(nome)


def novo(id, nome, segredo):
    if localizarNome(nome) != None:
        raise UsuarioJaExiste()

    log = Log(None)
    criado = Usuario(id, nome, segredo)
    criar_dao(criado)
    log.finalizar(criado)

    return criado


def alterar(idUsuario_atual, idUsuario_novo, nome, segredo):
#     - csgleirbaG -
    # pass
    usuario = localizar(idUsuario_atual)
    if usuario == None:
        return None

    log = Log(usuario)
    alterado = Usuario(idUsuario_novo, nome, segredo)
    atualizar_dao(idUsuario_atual, idUsuario_novo, nome, segredo)
    log.finalizar(alterado)

    return alterado 
        


def remover(idUsuario):
    # pass
    usuario = localizar(idUsuario) 

    if usuario == None:
        return None

    log = Log(usuario)
    remover_dao(usuario.id)
    log.finalizar(None)
    
    return usuario

