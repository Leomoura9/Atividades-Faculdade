# from model.aluno import Aluno
from flask import Blueprint, jsonify, request
from infra.validacao import validar_campos
from infra.to_dict import to_dict, to_disct_list
from services.mensagens_service import \
    listar as services_listar_mensagens, \
    localizar as service_buscar_mensagem, \
    novo as service_novo_mensagem, \
    alterar as service_alterar_mensagem, \
    remover as service_remover_mensagem, \
    MensagemJaExiste

from services.usuarios_service import \
    localizar as service_buscar_usuario

mensagem_app = Blueprint('mensagem_app', __name__, template_folder='templates')

campos = ["de", "para", "segredo", "texto"]
tipos = [int, int, str, str]

# ROTA: GET | FUNC: BUSCAR TODOS OS CONTEÚDOS DA ARRAY/BANCO DE DADOS CASO CONTENHA DADOS
@mensagem_app.route('/msg')
def Index():
    listar = services_listar_mensagens()
    return jsonify(to_dict(listar))


# ROTA: GET | FUNC: BUSCAR CONTEÚDO POR ID, ATRAVÉS DA REQUISIÇÃO VIA URL
# @mensagem_app.route('/msg/<int:id>?segredo=<str:segredo>&inicio=<str:inicio>&fim=<int:fim>', methods=['GET']) -- NÃO FUNCIONOU DA FORMA QUE FOI PROPOSTA PELO PROFESSOR
# @mensagem_app.route('/msg/<int:id>?segredo=<segredo>&mensagem=<int:idMensagem>', methods=['GET']) -- TAMBÉM NÃO FUNCIONAL
@mensagem_app.route('/msg/<int:id>/<segredo>/<int:idMensagem>', methods=['GET']) # -- ÚNICO MÉTODO FUNCIONAL 
def localizar(id, segredo, idMensagem):
#     - csgleirbaG -
    usuario = service_buscar_usuario(id)
    
    if usuario != None:
        if to_dict(usuario)['segredo'] != str(segredo):
            return '', 403
        
        mensagens = []
        listagem = to_dict(services_listar_mensagens())
        for x in listagem:
            if x['id_destinatario'] == idMensagem or x['id_destinatario'] == 0:
                x['de'] = x['id_remetente']
                x['para'] = x['id_destinatario']
                x['texto'] = x['texto']
                x['datahora'] = x['dataMensagem']
                mensagens.append({ 'de': x['de'], 'para': x['para'], 'texto': x['texto'], 'datahora': x['datahora']})
        
        if len(mensagens) > 0:
            return jsonify(to_dict(mensagens))

        return '', 404


# ROTA: POST | FUNC: CADASTRAR CONTEÚDO, ATRAVÉS DAS INFORMAÇÕES ENVIADAS VIA JSON
@mensagem_app.route('/msg', methods=['POST'])
def novo():
    import datetime
    dados = request.get_json()
    
    dados['segredo'] = str(dados['segredo'])

    if not validar_campos(dados, campos, tipos):
        return '', 422
    
    dados['id'] = len(to_dict(services_listar_mensagens())) + 1

    while service_buscar_mensagem(dados['id']) != None:
        dados['id'] += 1

    dados['data'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    usuario = service_buscar_usuario(dados['de'])
    if usuario != None:
        if str(to_dict(usuario)['segredo']) !=dados['segredo']:
            return '403', 403
        try:
            criado = service_novo_mensagem(dados['id'], dados['de'], dados['para'], dados['data'], dados['texto'])
            return jsonify(to_dict(criado))
        except MensagemJaExiste:
            return '409', 409
    return  '404', 404


# ROTA: PUT | FUNC: ALTERAR CONTEÚDO, ATRAVÉS DO ID ENVIADO VIA URL E DAS INFORMAÇÕES ENVIADAS VIA JSON
# @mensagem_app.route('/msg/<int:id>', methods=['PUT'])
# def alterar(id):
# #     - csgleirbaG -
#     dados = request.get_json()

#     if not validar_campos(dados, campos, tipos):
#         return '', 422
#     alterado = service_alterar_mensagem(id, dados['id'], dados['nome'], dados['segredo'])

#     if alterado != None:
#         return jsonify(to_dict(alterado))
#     return '', 404



# ROTA: DELETE | FUNC: DELETA A 'CHAVE' CONFORME O ID PASSADO VIA URL
# @mensagem_app.route('/msg/<int:id>', methods=['DELETE'])
# def remover(id):
#     removido = service_remover_mensagem(id,)
#     if removido != None:
#         return jsonify(to_dict(removido))
#     return '', 404
