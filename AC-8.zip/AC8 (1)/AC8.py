from flask import Flask, jsonify, request, render_template
from usuarios_api import usuario_app
from mensagem_api import mensagem_app
from infra.to_dict import to_dict  
from infra.db import criar_db 


app = Flask(__name__)  
app.register_blueprint(usuario_app)
app.register_blueprint(mensagem_app)

# from services.usuarios_service import \
    # listar as listar_usuarios, \

from services.mensagens_service import \
    listar as listar_mensagens
        

@app.route('/')
def all():
    database = {
        # "USUARIOS" : to_dict(listar_usuarios())
        "MENSAGENS" : to_dict(listar_mensagens())
    }
    return render_template('index.html', mensagens = to_dict(database['MENSAGENS']))


criar_db()

if __name__ == '__main__':
    app.run(host='localhost', port=8080)